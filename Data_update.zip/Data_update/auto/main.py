from Data_update.update_main import daily_update_705,daily_update_1515,daily_update_1800

def time_705():
    daily_update_705()

def time_1515():
    daily_update_1515()

def time_1800():
    daily_update_1800()

# time_1515()